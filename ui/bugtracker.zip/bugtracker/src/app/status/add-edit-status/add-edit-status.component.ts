import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-status',
  templateUrl: './add-edit-status.component.html',
  styleUrls: ['./add-edit-status.component.css']
})
export class AddEditStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
