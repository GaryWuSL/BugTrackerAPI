export interface ErrorResponse {
    error:string;
    errorCode: string;
}