export interface LoginRequest {
    UserName: string;
    Password: string;
}