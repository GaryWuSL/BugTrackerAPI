export interface ServiceResponse {
    Success:boolean;
    Error:string;
    ErrorCode: string;
    RecordCount:number;
}