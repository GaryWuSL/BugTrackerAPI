import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-priority',
  templateUrl: './add-edit-priority.component.html',
  styleUrls: ['./add-edit-priority.component.css']
})
export class AddEditPriorityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
