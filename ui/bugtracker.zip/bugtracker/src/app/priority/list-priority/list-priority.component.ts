import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-priority',
  templateUrl: './list-priority.component.html',
  styleUrls: ['./list-priority.component.css']
})
export class ListPriorityComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
